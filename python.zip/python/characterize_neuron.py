"""
==============================================================
AnalogFlow
Analog Neuron Characterization

Author : Arush Mangalam Bajpai

Description
-----------
This script automatically characterizes an analog neuron by
sweeping two input voltages across a configurable range.

Workflow

Vin1 Sweep
        ×
Vin2 Sweep
        ↓
Temporary LTspice Schematic
        ↓
LTspice Batch Simulation
        ↓
RAW Parsing
        ↓
Activation Surface
Classification Surface
        ↓
CSV + Heatmaps + Report

The original schematic is NEVER modified.
==============================================================
"""

from pathlib import Path
import shutil
import time
import re

import numpy as np
import matplotlib.pyplot as plt

from analogflow.runner import LTSpiceRunner
from analogflow.parser import LTSpiceParser


# ==========================================================
# USER CONFIGURATION
# ==========================================================

# Original LTspice schematic
SOURCE_SCHEMATIC = Path("analog/analog_parametric.asc")

# LTspice executable
LTSPICE_PATH = r"C:\Program Files\ADI\LTspice\LTspice.exe"

# Output directory
OUTPUT_DIR = Path("results/neuron_characterization")

# Temporary schematics
TEMP_DIR = OUTPUT_DIR / "temp"

# ----------------------------------------------------------

GRID_SIZE = 21

VIN_MIN = 0.0
VIN_MAX = 1.0

# ----------------------------------------------------------

SOURCE1 = "V1"
SOURCE2 = "V2"

# traces

OUTPUT_TRACE = "V(vout)"

ACTIVATION_TRACE = "V(n007)"

# threshold

CLASSIFICATION_THRESHOLD = 0.0

# save dpi

FIGURE_DPI = 300


# ==========================================================
# INITIALIZATION
# ==========================================================

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

runner = LTSpiceRunner(LTSPICE_PATH)

vin_values = np.linspace(
    VIN_MIN,
    VIN_MAX,
    GRID_SIZE,
)

activation_surface = np.zeros(
    (
        GRID_SIZE,
        GRID_SIZE,
    )
)

classification_surface = np.zeros(
    (
        GRID_SIZE,
        GRID_SIZE,
    )
)

failed_points = []


# ==========================================================
# HELPER FUNCTIONS
# ==========================================================

def print_banner():

    print("=" * 60)
    print(" AnalogFlow : Analog Neuron Characterization ")
    print("=" * 60)
    print(f"Grid Size           : {GRID_SIZE} x {GRID_SIZE}")
    print(f"Total Simulations   : {GRID_SIZE * GRID_SIZE}")
    print(f"Input Range         : {VIN_MIN:.2f} V -> {VIN_MAX:.2f} V")
    print()


def progress(current, total, vin1, vin2):

    print(
        f"[{current:4d}/{total}] "
        f"Vin1={vin1:.3f} V  "
        f"Vin2={vin2:.3f} V"
    )


def classify(value):

    return 1 if value > CLASSIFICATION_THRESHOLD else 0


# ==========================================================
# SCHEMATIC GENERATION
# ==========================================================

import re


def create_temporary_schematic(vin1, vin2, destination):

    text = SOURCE_SCHEMATIC.read_text(
        encoding="utf-8"
    )

    pattern_v1 = (
        r"(SYMATTR Value\s+PULSE\([^\)]*\)\s*"
        r"SYMATTR InstName\s+V1)"
    )

    replacement_v1 = (
        f"SYMATTR Value DC {vin1:.6f}\n"
        "SYMATTR InstName V1"
    )

    text = re.sub(
        pattern_v1,
        replacement_v1,
        text,
        flags=re.MULTILINE,
    )

    pattern_v2 = (
        r"(SYMATTR Value\s+PULSE\([^\)]*\)\s*"
        r"SYMATTR InstName\s+V2)"
    )

    replacement_v2 = (
        f"SYMATTR Value DC {vin2:.6f}\n"
        "SYMATTR InstName V2"
    )

    text = re.sub(
        pattern_v2,
        replacement_v2,
        text,
        flags=re.MULTILINE,
    )

    destination.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    destination.write_text(
        text,
        encoding="utf-8",
    )

    return destination# ==========================================================
# CHARACTERIZATION
# ==========================================================

def characterize():

    total = GRID_SIZE * GRID_SIZE
    completed = 0

    start_time = time.time()

    print_banner()

    for row, vin2 in enumerate(vin_values):

        for col, vin1 in enumerate(vin_values):

            completed += 1

            progress(
                completed,
                total,
                vin1,
                vin2,
            )

            schematic_name = (
                f"vin1_{vin1:.3f}_vin2_{vin2:.3f}"
                .replace(".", "_")
                + ".asc"
            )

            temp_schematic = TEMP_DIR / schematic_name

            try:

                # --------------------------------------------
                # Generate temporary schematic
                # --------------------------------------------

                create_temporary_schematic(
                    vin1,
                    vin2,
                    temp_schematic,
                )

                # --------------------------------------------
                # Run LTspice
                # --------------------------------------------

                runner.run(temp_schematic)

                raw_file = temp_schematic.with_suffix(".raw")

                parser = LTSpiceParser(raw_file)

                # --------------------------------------------
                # Read activation
                # --------------------------------------------

                activation = parser.get_trace(
                    ACTIVATION_TRACE
                )

                activation_value = float(
                    activation[-1]
                )

                activation_surface[row, col] = (
                    activation_value
                )

                # --------------------------------------------
                # Read output
                # --------------------------------------------

                output = parser.get_trace(
                    OUTPUT_TRACE
                )

                output_value = float(
                    output[-1]
                )

                classification_surface[row, col] = (
                    classify(output_value)
                )

            except Exception as error:

                print(
                    f"FAILED : "
                    f"Vin1={vin1:.3f} "
                    f"Vin2={vin2:.3f}"
                )

                print(error)

                failed_points.append(
                    (
                        vin1,
                        vin2,
                        str(error),
                    )
                )

                activation_surface[row, col] = np.nan

                classification_surface[row, col] = np.nan

    elapsed = time.time() - start_time

    print()

    print("=" * 60)

    print("Characterization Finished")

    print(f"Elapsed Time : {elapsed:.2f} s")

    print(f"Failed Points : {len(failed_points)}")

    print("=" * 60)

    return elapsed

# ==========================================================
# EXPORT RESULTS
# ==========================================================

def save_results(elapsed_time):

    print("\nSaving results...")

    # ------------------------------------------------------
    # Save CSV files
    # ------------------------------------------------------

    activation_csv = OUTPUT_DIR / "activation_surface.csv"
    classification_csv = OUTPUT_DIR / "classification_surface.csv"

    np.savetxt(
        activation_csv,
        activation_surface,
        delimiter=",",
        fmt="%.6f",
    )

    np.savetxt(
        classification_csv,
        classification_surface,
        delimiter=",",
        fmt="%d",
    )

    # ------------------------------------------------------
    # Activation Heatmap
    # ------------------------------------------------------

    plt.figure(figsize=(8, 7))

    plt.imshow(
        activation_surface,
        origin="lower",
        extent=[
            VIN_MIN,
            VIN_MAX,
            VIN_MIN,
            VIN_MAX,
        ],
        aspect="auto",
    )

    plt.title("Activation Surface")

    plt.xlabel("Vin1 (V)")

    plt.ylabel("Vin2 (V)")

    plt.colorbar(label="Activation Voltage (V)")

    plt.tight_layout()

    plt.savefig(
        OUTPUT_DIR / "activation_surface.png",
        dpi=FIGURE_DPI,
    )

    plt.close()

    # ------------------------------------------------------
    # Classification Heatmap
    # ------------------------------------------------------

    plt.figure(figsize=(8, 7))

    plt.imshow(
        classification_surface,
        origin="lower",
        extent=[
            VIN_MIN,
            VIN_MAX,
            VIN_MIN,
            VIN_MAX,
        ],
        aspect="auto",
        interpolation="nearest",
    )

    plt.title("Classification Surface")

    plt.xlabel("Vin1 (V)")

    plt.ylabel("Vin2 (V)")

    plt.colorbar(label="Class")

    plt.tight_layout()

    plt.savefig(
        OUTPUT_DIR / "classification_surface.png",
        dpi=FIGURE_DPI,
    )

    plt.close()

    # ------------------------------------------------------
    # Statistics
    # ------------------------------------------------------

    valid = classification_surface[
        ~np.isnan(classification_surface)
    ]

    high = np.sum(valid == 1)

    low = np.sum(valid == 0)

    report = OUTPUT_DIR / "characterization_report.txt"

    with open(report, "w") as f:

        f.write("=" * 60 + "\n")
        f.write("AnalogFlow Characterization Report\n")
        f.write("=" * 60 + "\n\n")

        f.write(f"Grid Size            : {GRID_SIZE} x {GRID_SIZE}\n")
        f.write(f"Total Simulations    : {GRID_SIZE * GRID_SIZE}\n")
        f.write(f"Execution Time       : {elapsed_time:.2f} s\n\n")

        f.write(f"Activation Trace     : {ACTIVATION_TRACE}\n")
        f.write(f"Output Trace         : {OUTPUT_TRACE}\n\n")

        f.write(f"HIGH Classifications : {high}\n")
        f.write(f"LOW Classifications  : {low}\n")
        f.write(f"Failed Simulations   : {len(failed_points)}\n")

        if failed_points:

            f.write("\nFailed Points\n")
            f.write("-" * 40 + "\n")

            for vin1, vin2, error in failed_points:

                f.write(
                    f"Vin1={vin1:.3f} "
                    f"Vin2={vin2:.3f}\n"
                )

                f.write(f"{error}\n\n")

    print("Done.")
# ==========================================================
# MAIN
# ==========================================================

def main():

    print_banner()

    try:

        elapsed_time = characterize()

        save_results(elapsed_time)

    finally:

        # --------------------------------------------------
        # Remove temporary files
        # --------------------------------------------------

        if TEMP_DIR.exists():

            shutil.rmtree(
                TEMP_DIR,
                ignore_errors=True,
            )

    print("\nCharacterization Complete.")
    print(f"Results saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":

    main()


